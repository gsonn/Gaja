Use Python version >= 3.3 only
Install dependencies using "pip install -r requirements.txt"
Make sure private key file is in this folder
Fill out teams.json
Run "python test.pyc"
Report will be in "reports" folder